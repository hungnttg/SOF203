package fpt.edu.poly.dothevinh.ph04785.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import fpt.edu.poly.dothevinh.ph04779.R;
import fpt.edu.poly.dothevinh.ph04785.model.SinhVien;

public class SinhVienAdapter extends ArrayAdapter<SinhVien> {
    Context context;
    int resource;
    List<SinhVien> list;
    public SinhVienAdapter( Context context, int resource,  List<SinhVien> objects) {
        super(context, resource, objects);
        this.context=context;
        this.resource=resource;
        this.list=objects;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row=LayoutInflater.from(context).inflate(R.layout.item_sinhvien,parent,false);
        TextView tvMasv=row.findViewById(R.id.tvMa);
        TextView tvTenSV=row.findViewById(R.id.tvTenSV);
        SinhVien sinhVien=list.get(position);
        tvMasv.setText("Id:"+sinhVien.getMaSV()+"-");
        tvTenSV.setText("Name:"+sinhVien.getTenSV());
        return row;
    }
}
