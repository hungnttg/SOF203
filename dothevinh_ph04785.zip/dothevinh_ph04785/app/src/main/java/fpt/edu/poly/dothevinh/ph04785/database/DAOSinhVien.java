package fpt.edu.poly.dothevinh.ph04785.database;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import fpt.edu.poly.dothevinh.ph04785.model.SinhVien;

public class DAOSinhVien {
    SqliteHelper sqliteHelper;

    public DAOSinhVien(SqliteHelper sqliteHelper) {
        this.sqliteHelper = sqliteHelper;
    }
    public void insertSinhVien(SinhVien sinhVien){
        SQLiteDatabase sqLiteDatabase=sqliteHelper.getReadableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(SqliteHelper.MASV,sinhVien.MaSV);
        contentValues.put(SqliteHelper.TENSINHVIEN,sinhVien.TenSV);
        sqLiteDatabase.insert(SqliteHelper.TABLE_SINHVIEN,null,contentValues);

    }
    public List<SinhVien> getAllSinhVien(){
        List<SinhVien> list=new ArrayList<>();
        SQLiteDatabase sqLiteDatabase=sqliteHelper.getReadableDatabase();
        String select="Select * from "+ SqliteHelper.TABLE_SINHVIEN;
        Cursor cursor=sqLiteDatabase.rawQuery(select,null);
        if (cursor.moveToFirst()){
            do {
                SinhVien sinhVien=new SinhVien();
                sinhVien.setMaSV(cursor.getString(cursor.getColumnIndex(SqliteHelper.MASV)));
                sinhVien.setTenSV(cursor.getString(cursor.getColumnIndex(SqliteHelper.TENSINHVIEN)));
                list.add(sinhVien);
            }while (cursor.moveToNext());
        }
        return list;
    }
    public  void update(SinhVien sinhVien){
        SQLiteDatabase sqLiteDatabase=sqliteHelper.getReadableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(SqliteHelper.MASV,sinhVien.MaSV);
        contentValues.put(SqliteHelper.TENSINHVIEN,sinhVien.TenSV);
        sqLiteDatabase.update(SqliteHelper.TABLE_SINHVIEN,contentValues, SqliteHelper.MASV+"=?",new String[]{sinhVien.MaSV});

    }
    public  void delete(SinhVien sinhVien){
        SQLiteDatabase sqLiteDatabase=sqliteHelper.getReadableDatabase();
        sqLiteDatabase.delete(SqliteHelper.TABLE_SINHVIEN, SqliteHelper.MASV+"=?",new String[]{sinhVien.getMaSV()});
    }
    public List<SinhVien> getMaSinhVien(String ma){
        List<SinhVien> list=new ArrayList<>();
        SQLiteDatabase sqLiteDatabase=sqliteHelper.getReadableDatabase();
        String select="Select * from "+ SqliteHelper.TABLE_SINHVIEN+" where "+ SqliteHelper.MASV+" like "+ma;
        Cursor cursor=sqLiteDatabase.rawQuery(select,null);
        if (cursor.moveToFirst()){
            do {
                SinhVien sinhVien=new SinhVien();
                sinhVien.setMaSV(cursor.getString(cursor.getColumnIndex(SqliteHelper.MASV)));
                sinhVien.setTenSV(cursor.getString(cursor.getColumnIndex(SqliteHelper.TENSINHVIEN)));
                list.add(sinhVien);
            }while (cursor.moveToNext());
        }
        return list;
    }
}
