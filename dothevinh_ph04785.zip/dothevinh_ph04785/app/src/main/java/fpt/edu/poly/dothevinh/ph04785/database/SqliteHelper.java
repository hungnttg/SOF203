package fpt.edu.poly.dothevinh.ph04785.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SqliteHelper extends SQLiteOpenHelper {
    public final static String DATABASE_NAME="1234.db";
    public final static String TABLE_SINHVIEN="SinhVien";
    public final static String MASV="MaSV";
    public final static String TENSINHVIEN="TenSV";
    public final static String CREATE_TABLE_SINHVIEN="CREATE TABLE "+TABLE_SINHVIEN+"( "+
            ""+MASV+" NVARCHAR(6) PRIMARY KEY,"+
            ""+TENSINHVIEN+" NVARCHAR(50)"+
            ")";



    public SqliteHelper( Context context ) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_SINHVIEN);
//        db.execSQL("INSERT INTO "+TABLE_SINHVIEN +"(MaSV,TenSV) VALUES (1,'Nguyễn Thúy Nga');");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
