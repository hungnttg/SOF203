package fpt.edu.poly.dothevinh.ph04785;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import fpt.edu.poly.dothevinh.ph04785.adapter.SinhVienAdapter;
import fpt.edu.poly.dothevinh.ph04785.database.DAOSinhVien;
import fpt.edu.poly.dothevinh.ph04785.database.SqliteHelper;
import fpt.edu.poly.dothevinh.ph04785.model.SinhVien;

public class MainActivity extends AppCompatActivity {
    EditText edtMaSV, edtTenSV,edtSearch;
    Button btnAdd, btnDelete, btnEdit;
    List<SinhVien> list;
    ListView lvSinhVien;
    TextView tvCount;
    SqliteHelper sqliteHelper;
    DAOSinhVien daoSinhvien;
    SinhVienAdapter sinhVienAdapter;
    String ma, ten;
    ImageView imgClose;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtMaSV = findViewById(R.id.edtMaSV);
        edtTenSV = findViewById(R.id.edtTenSV);
        edtSearch=findViewById(R.id.edtSearch);
        imgClose=findViewById(R.id.imgClose);
        btnAdd = findViewById(R.id.btnAdd);
        btnDelete = findViewById(R.id.btnDelete);
        btnEdit = findViewById(R.id.btnEdit);
        lvSinhVien = findViewById(R.id.lvStudent);
        tvCount = findViewById(R.id.tvCount);
        sqliteHelper = new SqliteHelper(this);
        daoSinhvien = new DAOSinhVien(sqliteHelper);
        initData();
        list = daoSinhvien.getAllSinhVien();
        sinhVienAdapter = new SinhVienAdapter(this, R.layout.item_sinhvien, list);
        lvSinhVien.setAdapter(sinhVienAdapter);
        sinhVienAdapter.notifyDataSetChanged();
        tvCount.setText("Số Lượng :" + list.size());
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ma = edtMaSV.getText().toString().trim();
                String ten = edtTenSV.getText().toString().trim();
                if (edtMaSV.length() == 0 || edtTenSV.length() == 0) {
                    Toast.makeText(MainActivity.this, "Không rỗng", Toast.LENGTH_SHORT).show();
                } else {
                    daoSinhvien.insertSinhVien(new SinhVien(ma, ten));
                    list = daoSinhvien.getAllSinhVien();
                    sinhVienAdapter = new SinhVienAdapter(MainActivity.this, R.layout.item_sinhvien, list);
                    lvSinhVien.setAdapter(sinhVienAdapter);
                    sinhVienAdapter.notifyDataSetChanged();
                    tvCount.setText("Số Lượng :" + list.size());
                    edtTenSV.setText("");
                    edtMaSV.setText("");
                }
            }
        });

        lvSinhVien.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ma = list.get(position).MaSV;
                ten = list.get(position).TenSV;
                edtMaSV.setText(ma);
                edtTenSV.setText(ten);
            }
        });
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                daoSinhvien.delete(new SinhVien(ma, ten));
                list = daoSinhvien.getAllSinhVien();
                sinhVienAdapter = new SinhVienAdapter(MainActivity.this, R.layout.item_sinhvien, list);
                lvSinhVien.setAdapter(sinhVienAdapter);
                sinhVienAdapter.notifyDataSetChanged();
                tvCount.setText("Số Lượng :" + list.size());
                edtMaSV.setText("");
                edtTenSV.setText("");
            }
        });
        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ten=edtTenSV.getText().toString().trim();
                String ma=edtMaSV.getText().toString().trim();
                if (edtMaSV.length()==0||edtTenSV.length()==0){
                    Toast.makeText(MainActivity.this, "Du lieu khong rong", Toast.LENGTH_SHORT).show();
                }else {
                    daoSinhvien.update(new SinhVien(ma,ten));
                    list = daoSinhvien.getAllSinhVien();
                    sinhVienAdapter = new SinhVienAdapter(MainActivity.this, R.layout.item_sinhvien, list);
                    lvSinhVien.setAdapter(sinhVienAdapter);
                    sinhVienAdapter.notifyDataSetChanged();
                    edtTenSV.setText("");
                    edtMaSV.setText("");
                }


            }
        });
        edtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String id=edtSearch.getText().toString().trim();
                if (!id.equals("")){

                    list.clear();

                   List<SinhVien> sinhVien = daoSinhvien.getMaSinhVien(id);

                   list.addAll(sinhVien);
//                    sinhVienAdapter = new SinhVienAdapter(MainActivity.this, R.layout.item_sinhvien, list);
//                    lvSinhVien.setAdapter(sinhVienAdapter);
                    sinhVienAdapter.notifyDataSetChanged();
                }else {
                    list = daoSinhvien.getAllSinhVien();
                    sinhVienAdapter = new SinhVienAdapter(MainActivity.this, R.layout.item_sinhvien, list);
                    lvSinhVien.setAdapter(sinhVienAdapter);
                    sinhVienAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        imgClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edtSearch.setText("");
                list = daoSinhvien.getAllSinhVien();
                sinhVienAdapter = new SinhVienAdapter(MainActivity.this, R.layout.item_sinhvien, list);
                lvSinhVien.setAdapter(sinhVienAdapter);
                sinhVienAdapter.notifyDataSetChanged();
            }
        });

    }

    public void initData() {
        daoSinhvien.insertSinhVien(new SinhVien("1", "Nguyễn Thúy Nga"));
        daoSinhvien.insertSinhVien(new SinhVien("2", "Trần Văn Minh"));
        daoSinhvien.insertSinhVien(new SinhVien("3", "Lê Văn Hoàng"));
        daoSinhvien.insertSinhVien(new SinhVien("4", "Phạm Đại Chí"));
        daoSinhvien.insertSinhVien(new SinhVien("5", "Trương Đại Tín"));
        daoSinhvien.insertSinhVien(new SinhVien("6", "Hồ Đại Đức"));
    }
}
